package com.project.LibraryManagement.vo;

public record CategoryRecord(Long id,String name) {

}
