package com.project.LibraryManagement.vo;

public record BookRecord(Long id, String isbn, String name, String serialName, String description) {
}
