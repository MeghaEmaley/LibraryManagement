package com.project.LibraryManagement.vo;

public record AuthorRecord(Long id, String name, String description) {

}
