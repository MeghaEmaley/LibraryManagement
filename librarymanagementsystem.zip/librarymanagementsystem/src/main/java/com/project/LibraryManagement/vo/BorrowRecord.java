package com.project.LibraryManagement.vo;

public record BorrowRecord(Long id, String name) {

}
