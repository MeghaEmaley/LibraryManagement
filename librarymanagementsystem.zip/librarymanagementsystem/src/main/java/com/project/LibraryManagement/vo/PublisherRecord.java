
package com.project.LibraryManagement.vo;

public record PublisherRecord(Long id, String name) {

}
